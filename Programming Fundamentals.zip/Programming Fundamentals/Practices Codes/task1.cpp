#include<iostream>
#include<fstream>
using namespace std;
void copy(double* old, double* n, int s)
{
	for (int i = 0; i < s; i++)
	{
		n[i] = old[i];
	}
}
double* regrow(double* oldarray, int& s, int v)
{
	double* newarray = new double[s + 1];
	copy(oldarray, newarray, s);
	newarray[s] = v;
	s++;
	delete[]oldarray;
	oldarray = NULL;
	return newarray;
}
void read(double* arr, int s)
{
	ifstream fin;
	fin.open("marks.txt");
	fin >> s;
	for (int i = 0; i < s; i++)
	{
		fin>> arr[i] ;
	}
	fin.close();
}
double* add_data(double* arr, int& s)
{
	int n = 0;
	double val=0;
	int m = 0;
	cout << "Enter the number of Quiz you want to add marks : ";
	cin >> n;
	m = s + n;
	for (int i = 0; i < n; i++)
	{
		cout << "Enter the numbers for Quiz " << i + 1 << " : ";
		cin >> val;
		arr = regrow(arr, s, val);
	}
	s = m;
	return arr;
}
double sum(double* arr, int s)
{
	double sum1 = 0;
	for (int i = 0; i < s; i++)
	{
		sum1 = sum1 + arr[i];
	}
	return sum1;
}
void display(double* arr, int s)
{
	for (int i = 0; i < s; i++)
	{
		cout << arr[i] << " ";
	}
}
void write(double* arr, int s)
{
	ofstream fout;
	fout.open("marks.txt");
	fout << s << endl;
	for (int i = 0; i < s; i++)
	{
		fout << arr[i] << " ";
	}
	fout.close();
}
int main()
{
	int size = 0;
	double average = 0;
	double total = 0;
	ifstream fin;
	fin.open("marks.txt");
	fin >> size;
	fin.close();
	double* ptr = new double[size];
	read(ptr, size);
	display(ptr, size);
	ptr=add_data(ptr, size);
	total = sum(ptr, size);
	average = total / size;
	write(ptr, size);
	ofstream fout;
	fout.open("output.txt");
	fout << average;
	fout.close();
	delete[]ptr;
	return 0;
}