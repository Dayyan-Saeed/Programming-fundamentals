#include<iostream>
#include<fstream>
using namespace std;

void copyArray(int *newarray, int *oldarray, int s)
{
	for (int i = 0; i<s; i++)
		newarray[i] = oldarray[i];
} 

int* regrow1D(int *oldarray, int &s, int value)
{
	int *newarray = NULL;
	newarray = new int[s + 1];1
	copyArray(newarray, oldarray, s);
	newarray[s] = value;
	s++;
	delete[] oldarray;
	return newarray;
}

void DisplayArray(int * data, int size)
{
	for (int i = 0; i < size; i++)
	{
		cout << *(data + i) << endl;
	}
}

int* shrink(int* ptr, int &size,int key)
{
	int* newarray = new int[size-1];
	
	int index = 0;
	for (int i = 0; i < size; i++)
	{
		if (key != ptr[i])
		{
			newarray[index] = ptr[i];
			index++;
		}
	}

	size=index;
	delete[]ptr;
	return newarray;
}

int main()
{
	char filename[20] = "input.txt";
	int *data = NULL;
	int size = 0;
	int num = 0;
	ifstream fin;
	fin.open(filename);
	fin >> num;
	data = new int[1];
	data[0] = num;
	size++;
	while (fin >> num){
		data = regrow1D(data, size, num);
	}
	DisplayArray(data, size);

	cout << endl << endl;

	data = shrink(data, size,7);
		
	DisplayArray(data, size);

	return 0;
}


