#include<iostream>
#include<fstream>
using namespace std;

void display(int* data, int size);
void copyarray(int* newa, int* olda, int size) {
	for (int i = 0; i < size; i++) {
		newa[i] = olda[i];
	}
}
int* regrow(int* olda, int value, int size) {
	if (size == 0) {
		olda = new int[1];
		olda[0] = value;
		return olda;
	}
	else
	{
		int* newa = NULL;
		newa = new int[size + 1];
		copyarray(newa, olda, size);
		newa[size] = value;
		delete[] olda;
		return newa;
	}
}
int* shrinkid(int *ptr, int &size) {
	int* ptr2 = NULL;
	if (size == 0) {
		delete[] ptr;
	}
	else {
		ptr2 = new int[size - 1];
		size--;
		copyarray(ptr2, ptr, size);
		delete[] ptr;
	}
	return ptr2;

}

int* shrinkatindex(int* ptr, int &size, int index) {
	int* ptr2 = NULL;
	if (size == 0) {
		delete[] ptr;
	}
	else {
		ptr2 = new int[size - 1];
		size--;
		for(int i = index; i <size; i++) { // left shift
			ptr[i] = ptr[i + 1];
		}
		copyarray(ptr2, ptr, size);
		delete[] ptr;
	}
	return ptr2;
}
int* addatspecificpoint(int* olda, int &size, int value, int index)
{

	int temp;
	if (size == 0) {
		olda = new int[1];
		olda[0] = value;
		return olda;
	}
	else
	{
		int y;
		int *newa = new int[size + 1];   //size 7
		size++;
		for (int i = 0; i < size; i++) {
			if (i == index) {
				for (int j = index; j < size; j++) {
						y = ++i;
						newa[y] = olda[j];
				}
				newa[index] = value;
			}
			else 
			{
				newa[i] = olda[i];
			}
		}
		delete[] olda;
		return newa;
	}
}//end of function
void display(int* data, int size) {
	for (int i = 0; i < size; i++) {
		cout << data[i] << "\t";
	}
	cout << endl;
}
int main() {
	int* olda = NULL;
	int size = 0;
	int num;
	ifstream file;
	file.open("input.txt");
	while (file >> num) {
		olda = regrow(olda, num, size);
		size++;
	}
	display(olda, size);

	/*cout << "\nafter shrink at end" << endl;
	while (size>0) {
		olda = shrinkid(olda,size);
		display(olda, size);
	}*/


	/*int index=0;
	cout << "shrink at specific point" << endl;
	cin >> index; 
	olda = shrinkatindex(olda, size,index);
	display(olda, size);
	*/
	int in, value2=0;
	cout << "add element at specfic index" << endl;
	cin >> in;
	cout << "value to be aadd" << endl;
	cin >> value2;

	olda=addatspecificpoint(olda, size, value2, in);
	display(olda, size);



	//char n[5]="helo";
	//cout << n;

	/*char name[3][6];
	for (int i = 0; i < 2; i++) {
		cin.getline(name[i],6);
	}
	
	for (int i = 0; i < 2; i++) {
		cout<< name<<"\t";
	}*/

	
	

}
