#include<iostream>
#include<fstream>
using namespace std;
int** readFromFile(char*, int&, int*&);
int* regrow1D(int*, int);
int** regrow2D(int**, int);
void display(int**, int, int*);
int main()
{
	char file[20] ="data.txt";
	int**ptr, row = 0, *col;
	ptr = readFromFile(file, row, col);
	display(ptr, row, col);
	
	return 0;
}
int** readFromFile(char* fileName, int& row, int* &col)
{
	int num = 0, **temp = NULL;
	ifstream fin;
	fin.open(fileName);
	if (fin.is_open())
	{
		temp = regrow2D(temp, row);
		col = regrow1D(col, row);
		row++;
		while (fin >> num)
		{
			temp[row - 1] = regrow1D(temp[row - 1], col[row - 1]);
			temp[row - 1][col[row - 1]] = num;
			col[row - 1]++;
		}
		fin.close();
			return temp;
	}
	else
	{
		cout << "File not open for readig." << endl;
	}
}
int* regrow1D(int*ptr, int size)
{
	int*temp = NULL;
	temp = new int[size + 1];
	for (int i = 0; i < size; i++)
		temp[i] = ptr[i];

	return temp;
}
int** regrow2D(int**ptr, int size)
{
	int**temp = NULL;
	temp = new int*[size + 1];
	for (int i = 0; i < size; i++)
		temp[i] = ptr[i];
	
	return temp;
}
void display(int**ptr, int row, int*col)
{
	for (int r = 0; r < row; r++)
	{
		for (int c = 0; c < col[r]; c++)
		{
			cout << ptr[r][c] << " ";
		}
		cout << endl;
	}
}

