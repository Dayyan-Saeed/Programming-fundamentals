#include<iostream>
#include<fstream>
using namespace std;


void copyArray(int **newarray, int **oldarray, int s)
{
	for (int i = 0; i<s; i++)
	{
		newarray[i] = oldarray[i];
	}	
}

int** regrow2D(int **oldarray, int &s,  int value)
{
	int **newarray = new int*[s + 1];
	copyArray(newarray, oldarray, s);
	newarray[s] =new int[1];
	newarray[s][0] = value;
	s++;
	delete[] oldarray;
	return newarray;
}

void DisplayArray(int ** data, int r,int *l)
{
	for (int i = 0; i < r; i++)
	{
		for(int j=0;j<l[i];j++)
		{
			cout << data[i][j] << " ";
		}
		cout<<endl;
	}
}
int main()
{
	char filename[20] = "input.txt";
	int **data = NULL;
	int size = 0;
	int num = 0;
	ifstream fin;
	fin.open(filename);
	fin >> num;
	data = new int*[3];
	data[0][0] = num;
	size++;
	while (fin >> num)
	{
		data = regrow1D(data, size, num);
	}
	DisplayArray(data, size,size);
	return 0;
}

