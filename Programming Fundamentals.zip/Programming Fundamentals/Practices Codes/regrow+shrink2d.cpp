#include<iostream>
#include<fstream>
using namespace std;  //col regrow
char* regrow(char* Data, int lenght, char value) 
{
	char* temp = NULL;
	if (lenght == 1) 
	{
		Data = new char[lenght];
		Data[lenght - 1] = value;
		return Data;
	}
	else 
	{
		temp = new char[lenght];
		for (int i = 0; i < lenght - 1; i++) 
		{
			temp[i] = Data[i];
		}
		temp[lenght - 1] = value;
		delete[] Data;
		return temp;
	}
}
void readData(ifstream& fin, char** Data, int row, int* lenght) 
{
	char temp = '\0'; 
	int size = 0; 
	int k = 0;
	for (int i = 0; i < row; i++) 
	{
		fin.get(temp);
		//cout << temp;
		while (temp != '\n') 
		{
			if (temp == ' ')
			{
				fin.get(temp);
				continue;
			}
			else
			{
				size++;
				Data[i] = regrow(Data[i], size, temp);
				fin.get(temp);
				//cout << temp;
			}
		}
		lenght[i] = size;   // lenght[i]=++size;or (*(lenght+i))++ or (lenght[i])++;
		size = 0;
		Data[i][lenght[i]] = '\0';
	}//for loop		

}//end of function read
void display(char** data, int r, int* lenght) 
{
	for (int i = 0; i < r; i++) 
	{
		for (int j = 0; j < lenght[i]; j++) 
		{
			cout << data[i][j] << "\t";
		}
		cout << endl;
	}
}
void copyarray(char* newa, char* olda, int size) 
{
	for (int i = 0; i < size; i++) 
	{
		newa[i] = olda[i];
	}
}
char* shrinkatindex(char* ptr, int &size, int index) 
{
		char* ptr2 = NULL;
		ptr2 = new char[size - 1];
		size--;
		for (int i = index; i < size; i++) 
		{ // left shift
			ptr[i] = ptr[i + 1];
		}
		copyarray(ptr2, ptr, size);
		delete[] ptr;
	return ptr2;
}
void shrink_2d(char** Data, int row, int* lenght, char r) 
{
	bool index = false;
	int size = 0;
	for (int i = 0; i < row; i++) 
	{
		for (int j = 0; j < lenght[i]; j++) 
		{
			if (r == Data[i][j]) 
			{
				index = true;
				cout <<"found at "<< i << "\t" << j<<endl;
				Data[i]=shrinkatindex(Data[i], lenght[i],j);
			}
			else 
			{
				continue;
			}
		}
	}
	if (index == false) 
	{
		cout << "not found"<<endl;
	}

}
int main() 
{
	//const char *filename="colre.txt";
	ifstream fin;
	int row = 0;
	int* lenght = NULL;
	char** Data = NULL;
	fin.open("col.txt");
	char temp = '\0';
	if (fin.is_open())
	{
		fin >> row;
		lenght= new int[row];
		fin.get(temp); //for reading \n
		Data = new char* [row];
		readData(fin, Data, row, lenght);
	}
	else 
	{
		cout << "failed to load";
	}
	cout << "populated array" << endl;
	display(Data, row, lenght);
	cout << "After eliminate from the array" << endl;
	shrink_2d(Data, row, lenght,'Q');
	display(Data, row, lenght);

}//END OF MAIN 

 
