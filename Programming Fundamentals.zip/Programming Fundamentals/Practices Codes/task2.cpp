#include<iostream>
#include<fstream>
using namespace std;
char** makedynamic(char** n, int r, int* c)
{
	ifstream fin;
	char** a = new char* [r];
	int cn = 0;
	fin.open("names.txt");
	fin >> cn;
	for (int i = 0; i < r; i++)
	{
		fin >> cn;
		c[i] = cn;
		a[i] = new char[c[i]];
		for (int j = 0; j < c[i]; j++)
		{
			fin >> a[i][j];
		}
	}
	fin.close();
	return a;
}
void sort(char** a, int r,int* c)
{
	char* tempc;
	int temp;
	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < r - 1; j++)
		{
			if (a[j][0] > a[j + 1][0])
			{
				tempc = a[j];
				a[j] = a[j + 1];
				a[j + 1] = tempc;
				temp = c[j];
				c[j] = c[j + 1];
				c[j + 1] = temp;
			}
		}
	}
}
void write(char** a, int r, int* c)
{
	ofstream fout;
	fout.open("sortbynames.txt");
	fout << r << endl;
	for (int i = 0; i < r; i++)
	{
		fout << c[i] << "  ";
		for (int j = 0; j < c[i]; j++)
		{
			fout << a[i][j];
		}
		fout << endl;
	}
	fout.close();

}
void display(char** a, int r, int* c)
{
	for (int i = 0; i < r; i++)
	{
		cout << c[i] << "  ";
		for (int j = 0; j < c[i]; j++)
		{
			cout << a[i][j];
		}
		cout << endl;
	}
}
int main()
{
	
	int row;
	ifstream fin;
	fin.open("names.txt");
	fin >> row;
	fin.close();
	int* col = new int[row];
	char** p = new char* [row];
	p=makedynamic(p, row, col);
	display(p, row, col);
	cout << endl << "After sort : " << endl;
	sort(p, row,col);
	display(p, row, col);
	write(p, row, col);
	for (int i = 0; i < row; i++)
	{
		delete[]p[i];
	}
	delete[]p;
	p = NULL;
	return 0;
}