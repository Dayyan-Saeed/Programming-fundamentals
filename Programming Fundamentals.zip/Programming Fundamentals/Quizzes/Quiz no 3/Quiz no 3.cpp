#include<iostream>
#include<fstream>
using namespace std;
int read(ifstream &fin)
{
	fin.open("input.txt");
	int count = 0;
	int val;
	while (fin >> val)
	{
		count++;					//counts size of file
	}
	fin.close();
	return count;
}
void copy(int *ptrarr,ifstream &fin)
{
	fin.open("input.txt");
	int i = 0;
	while (fin >> ptrarr[i])		//puts data in integer array
	{
		cout << ptrarr[i]<<" ";
		i++;
	}
	cout << endl;
	fin.close();
}
void write(ofstream &fout, int count,int *ptrarr)
{
	fout.open("input.txt");
	cout << "Appending\n";			//Appending
	cout << count << " ";
	fout << count<< " ";
	for (int i = 0; i < count; i++)
	{
		cout << ptrarr[i] << " ";
		fout << ptrarr[i] << " ";
	}
	fout.close();
}
int main()
{
	ifstream fin;					
	int count = read(fin);			//return size of file
	int *ptrarr = new int[count];	//dynamic allocation
	copy(ptrarr, fin);				//copying data to integer array whose size = size of file
	ofstream fout;
	write(fout,count,ptrarr);		//writing count(size of file) and values into same input.txt file
	delete[]ptrarr;					//deallocation
	ptrarr = NULL;
	return 0;
}
