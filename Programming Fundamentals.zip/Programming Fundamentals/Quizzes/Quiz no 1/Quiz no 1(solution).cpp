#include<iostream>
using namespace std;
int main()
{
	char arr[100];																					  //Declaration
	cout << "Enter array\n";
	cin.getline(arr, 100);																			  //Input
	int count = 0;
	for (int i = 0; arr[i] != '\0'; i++)															  //Main loop
	{
		if (arr[i] >= 'a' && arr[i] <= 'z' || arr[i] >= 'A' && arr[i] <= 'Z')						  //If index contains an ALPHABET THEN
		{																							  //make a copy of loop control variable(that is 'i')
			int j = i;
			while (arr[j] >= 'a' && arr[j] <= 'z' || arr[j] >= 'A' && arr[j] <= 'Z' && arr[j] != '\0')//increment in 'i' until any character other than an ALPHABET is encountered( it can be space or any special character)
			{
				j++;																				  
			}
			i = --j;																				  //resign value of substitue to loop control variable
			count++;																				  //only increment in count if and only if Line 11 evalutes to true
		}
	}
	cout << "Number of words in array = "<<count<<endl;
}