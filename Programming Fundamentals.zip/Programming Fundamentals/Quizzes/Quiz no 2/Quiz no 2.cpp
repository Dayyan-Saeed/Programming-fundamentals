#include<iostream>
using namespace std;
void changecase(char arr[])
{
	for (int i = 0; arr[i] != '\0'; i++)
	{
		if (arr[i] >= 'a'&& arr[i] <= 'z')		//Changing case for lower case characters
		{
			arr[i] = arr[i] - 32;
		}
		else if (arr[i] >= 'A'&& arr[i] <= 'Z')	//Changing case for upper case characters
		{
			arr[i] = arr[i] + 32;
		}
	}
}
void display(char arr[])
{
	cout << "\nUpdated array after changing CASE is\n" << arr << endl;
}
int main()
{
	char arr[100];								//Declaration
	cout << "Enter array\n";
	cin.getline(arr, 100);						//Input
	changecase(arr);							//FUNCTION call (control transfer to changecase())
	display(arr);								//FUNCTION call (control transfer to display())
	return 0;
}
