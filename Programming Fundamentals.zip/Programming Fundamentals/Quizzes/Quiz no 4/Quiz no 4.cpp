#include<iostream>
#include<fstream>
using namespace std;
void display(int table[3][6], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << table[i][j]<<"         ";
		}
		cout <<endl;
	}
}
void read(ifstream &fin, int table[3][6], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		int sum = 0;
		int j = 0;
		for (j = 0; j < col-1; j++)			//col-1 to stop fin>>table[i][j] as last column is reserved for total
		{
			fin >>table[i][j];
			sum = sum + table[i][j];
		}
		table[i][j] = sum - table[i][0];	//subtracting table[i][0] because it contains year which is not relevant to calculations
	}
}
int main()
{
	ifstream fin;
	fin.open("data.txt");			//opening for reading
	char arr[100];					//dumping header
	fin.getline(arr, 100);
	cout << "YEAR  Quarter 1  Quarter 2  Quarter 3  Quarter 4       Total\n";	//writing header
	int table[3][6];				//as we know file structure so we have created array of known size
	read(fin,table,3,6);
	display(table, 3, 6);
}